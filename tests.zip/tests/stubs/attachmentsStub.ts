export const attachmentsStub = [
  {
    name: 'attachment1',
    belongsToID: '1',
    purpose: 'boreholeLog',
  },
  {
    name: 'attachment2',
    belongsToID: '1',
    purpose: 'image',
  },
  {
    name: 'attachment3',
    belongsToID: '2',
    purpose: 'boreholeLog',
  }
];
